var bow, bowImage;

var blueBall, blueBallImage;

var redBall, redBallImage;

var greenBall, greenBallImage;

var yellowBall, yellowBallImage;

var scene, sceneImage;

var arrow, arrowImage;

var Score

function preload(){
bowImage = loadImage("bow0.png")

blueBallImage = loadImage("blue_balloon0.png");

redBallImage = loadImage("red_balloon0.png");

greenBallImage = loadImage("green_balloon0.png");

yellowBallImage = loadImage("pink_balloon0.png");
  
sceneImage = loadImage("background0.png")
  
arrowImage = loadImage("arrow0.png");


}

function setup() {
createCanvas(400, 400);
  
Score = 0;


scene = createSprite(200,200)
scene.addImage(sceneImage);
scene.velocityX = -5
scene.scale = 2


  
bow = createSprite (300,200,20,20);
bow.addImage (bowImage); 


 



}

function draw() {
background ("white")
}  
drawSprites ();
textSize (20);
text("Score :"+ Score,270,30);
}
function redBalloon () {
redBall = createSprite(0,random (20,380), 20, 20);
redBall.velocityX = 4;
redBall.addImage (redBallImage);
redBall.scale = 0.1
redBall.lifetime = 100


}

function greenBalloon () {
greenBall = createSprite(0,random (20,380), 20, 20);
greenBall.addImage (greenBallImage);
greenBall.scale = 0.1
greenBall.velocityX = 4
greenBall.lifetime = 100


}

function yellowBalloon () {
yellowBall = createSprite(0,random (20,380), 20, 20);
yellowBall.addImage (yellowBallImage);
yellowBall.scale = 1.5
yellowBall.velocityX = 4
yellowBall.lifetime = 100


}

function blueBalloon () {
blueBall = createSprite(0,random (20,380), 20, 20);
blueBall.addImage (blueBallImage);
blueBall.velocityX = 4
blueBall.scale = 0.1
blueBall.lifetime = 100


}

function Arrow () {
arrow = createSprite (100,100,60,10)
arrow.addImage(arrowImage);
arrow.x = 360
arrow.scale = 0.2
arrow.y = bow.y;
arrow.lifetime = 100;
}

